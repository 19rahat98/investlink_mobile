
/// Репозиторий для работы с нстройками приложения
class GlobalSettingsRepository {
  bool get loadLocationSetting{
    return true;
  }
}

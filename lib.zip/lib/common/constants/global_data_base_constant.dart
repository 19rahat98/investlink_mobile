/// константы хранят в себе все что связано с локальной базой данных
class GlobalDataBaseConstant {}

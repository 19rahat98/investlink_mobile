class GlobalKeyConstant {
  static const yandeMapKey = '';
  static const yandexAppmetricaKey = '';
  static const smartLookApiKey = '';
  static const amplitudeApiKey = '';
}

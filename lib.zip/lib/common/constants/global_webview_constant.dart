class GlobalWebViewConstant {}

class GlobalDioConstant {
  static const authorized = 'authorized';
}

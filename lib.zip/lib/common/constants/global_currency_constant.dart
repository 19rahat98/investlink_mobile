class GlobalCurrencyConstant {
  static const kztSymbol = ' ₸';
  static const usdSymbol = ' \$';
  static const eurSymbol = ' €';
  static const rubSymbol = ' ₽';
  static const kzt = "KZT";
  static const usd = "USD";
  static const eur = "EUR";
  static const rub = "RUB";
}

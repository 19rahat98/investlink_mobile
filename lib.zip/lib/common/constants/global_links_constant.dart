class GlobalLinksConstant {
  static const whatsAppLink = "";
}

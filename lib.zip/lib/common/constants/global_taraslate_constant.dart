/// содержит ключи локализации
class GlobalTranslateConstant {
  /// Общие
  static const en = 'en';
  static const ru = 'ru';
  static const kk = 'kk';
}

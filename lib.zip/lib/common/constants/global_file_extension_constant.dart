class GlobalExtensionFileConstant {
  static const jpg = ".jpg";
  static const pdf = ".pdf";
  static const mp3 = ".mp3";
}

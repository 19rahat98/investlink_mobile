/// константы для работы с изолятами
class GlobalIsolateConstant {
  /// константа для планирования локальных уведомлений
  static const scheduleNotifications = "scheduleNotifications";
}

import 'package:investlink_mobile/bootstrap.dart';
import 'package:investlink_mobile/core/app/app.dart';


void main() {
  mainDelegate();
  bootstrap(() => const App());
}

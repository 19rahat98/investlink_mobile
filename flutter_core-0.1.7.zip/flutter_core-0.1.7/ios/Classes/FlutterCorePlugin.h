#import <Flutter/Flutter.h>

@interface FlutterCorePlugin : NSObject<FlutterPlugin>
@end

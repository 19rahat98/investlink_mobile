package com.example.flutter_core_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

abstract class CoreEvent {}

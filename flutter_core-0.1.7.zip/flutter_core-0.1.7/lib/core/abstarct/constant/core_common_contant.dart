class CoreConstant {
  static const zeroDouble = 0.0;
  static const empty = '';
  static const negative = -1;
  static const zeroInt = 0;
}

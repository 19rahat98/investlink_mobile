class CoreNetworkConstant {
  static const socketException = "SocketException";
}

extension StringExtension on String {}
